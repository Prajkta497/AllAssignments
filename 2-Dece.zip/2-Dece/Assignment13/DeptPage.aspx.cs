﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class DeptPage : System.Web.UI.Page
{
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=PRAGMASYS-PC94\\MSSQLSERVER001;Initial Catalog=TrainingDb;Integrated Security=True");
    }

    protected void btn1_Click(object sender, EventArgs e)
    {
        TimeSpan ts = new TimeSpan(0, 0, 10);

       if (Cache["department"] == null)
        {
            
            DataTable dt = new DataTable("department");

            dt.Columns.Add("deptno", typeof(int));

            dt.Columns.Add("deptname", typeof(string));

            DataRow rs = dt.NewRow();

            rs[0] = TextBox1.Text;
            rs[1] =TextBox2.Text;
            dt.Rows.Add(rs);

            Cache["department"] = dt;
            Cache.Insert("department",dt);
            Response.Write("Its processing with Database hit");
        }

        else

        {
            Response.Write("Its processing from cache");
        }
       
     
    }

    protected void btn2_Click(object sender, EventArgs e)
    {
        GridView1.DataSource = (DataTable)Cache["Employee"];
        GridView1.DataBind();
    }
}