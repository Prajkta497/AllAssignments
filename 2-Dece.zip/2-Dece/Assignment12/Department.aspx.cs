﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Department : System.Web.UI.Page
{
    //Create a Department.aspx page in ASP.NET WebForm app.This page will display
    //    list of Departments in in GridView.Create Employee.aspx to show
    //        list of Employees in GridView.When a specific department is selected from GridView of
    //        Department.aspx, the navigation should takes place to display Employee.aspx showin
    //        Employees from the Department selected from Department.aspx GridView. 


   SqlConnection con;
    SqlDataReader dr;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        con = new SqlConnection("Data Source=PRAGMASYS-PC94\\MSSQLSERVER001;Initial Catalog=TrainingDb;Integrated Security=True");
        cmd = new SqlCommand("select * from department", con);
        con.Open();
        dr = cmd.ExecuteReader();
        GridView1.DataSource = dr;
        GridView1.DataBind();
        con.Close();
    }

    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        //string namep =GridView1.SelectedRow.Cells[0].Text;
        //ViewState["name"] = namep;
        //Server.Transfer("Employee.aspx");
        HttpCookie ht = new HttpCookie("mycookies");
        ht.Values.Add("nm", GridView1.SelectedRow.Cells[0].Text);
        Response.Cookies.Add(ht);
        Response.Redirect("Employee.aspx");
    }
}